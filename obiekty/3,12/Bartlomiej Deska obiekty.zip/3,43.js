const osoba = {
  nazwisko: "Nowacki",
  imie: "Marek",
  zawod: "informatyk",
  pokaz() { document.write(`${this.nazwisko} ${this.imie}`) }
}